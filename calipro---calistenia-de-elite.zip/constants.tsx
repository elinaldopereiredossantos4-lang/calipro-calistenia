
import { Difficulty, MuscleGroup, Exercise, WorkoutDay } from './types';

export const EXERCISES: Record<string, Exercise> = {
  'pushup': {
    id: 'pushup',
    name: 'Flexão de Braços Clássica',
    muscles: [MuscleGroup.CHEST, MuscleGroup.TRICEPS, MuscleGroup.SHOULDERS],
    description: 'O exercício fundamental para força de empurrar da parte superior do corpo.',
    instructions: [
      'Inicie na posição de prancha alta.',
      'Mantenha o abdômen contraído e o corpo reto.',
      'Desça o peito até quase tocar o chão.',
      'Empurre o chão com força para voltar à posição inicial.'
    ],
    postureAlerts: [
      'Não deixe o quadril cair.',
      'Mantenha os cotovelos a 45 graus do corpo.'
    ],
    breathing: 'Inspire ao descer, expire ao subir.',
    animationUrl: 'https://media.giphy.com/media/v1.Y2lkPTc5MGI3NjExM2FwYnp1Y2dyYWZndDZ4amV0ZWQyeHpsYXU1YndhMzhjNmtpZm94OCZlcD12MV9pbnRlcm5hbF9naWZfYnlfaWQmY3Q9Zw/L59v2V1oT8z39SclKq/giphy.gif'
  },
  'pullup': {
    id: 'pullup',
    name: 'Barra Fixa Pronada',
    muscles: [MuscleGroup.BACK, MuscleGroup.BICEPS, MuscleGroup.CORE],
    description: 'Exercício de elite para costas largas e braços fortes.',
    instructions: [
      'Segure a barra com as palmas voltadas para frente.',
      'Puxe o corpo para cima até o queixo passar a barra.',
      'Controle a descida lentamente.'
    ],
    postureAlerts: [
      'Não use impulso com as pernas (kipping).',
      'Ative as escápulas antes de iniciar o movimento.'
    ],
    breathing: 'Expire ao subir, inspire ao descer.',
    animationUrl: 'https://media.giphy.com/media/v1.Y2lkPTc5MGI3NjExMThjOTY4OTgyNTA4OTgyODkwODkwODkwODkwODkwODkwODkwODkwODkmZXBfdjFfaW50ZXJuYWxfZ2lmX2J5X2lkJmN0PWc/uVpP7tclM6T7X7I2O8/giphy.gif'
  },
  'squat': {
    id: 'squat',
    name: 'Agachamento Livre',
    muscles: [MuscleGroup.LEGS, MuscleGroup.CORE],
    description: 'Base para membros inferiores poderosos.',
    instructions: [
      'Pés na largura dos ombros.',
      'Desça o quadril como se fosse sentar em uma cadeira.',
      'Mantenha o calcanhar firme no chão.'
    ],
    postureAlerts: [
      'Não deixe os joelhos colapsarem para dentro.',
      'Mantenha o peito aberto e coluna neutra.'
    ],
    breathing: 'Inspire ao descer, expire ao subir.',
    animationUrl: 'https://media.giphy.com/media/v1.Y2lkPTc5MGI3NjExNjk1OTQ4NDY5NDY5NDY5NDY5NDY5NDY5NDY5NDY5NDY5NDY5NDY5JmVwX3YxX2ludGVybmFsX2dpZl9ieV9pZCZjdD1n/m949Yw28FMTuof05hO/giphy.gif'
  },
  'plank': {
    id: 'plank',
    name: 'Prancha Abdominal',
    muscles: [MuscleGroup.CORE, MuscleGroup.SHOULDERS, MuscleGroup.ABS],
    description: 'Fortalecimento isométrico total do core.',
    instructions: [
      'Apoie os antebraços no chão.',
      'Mantenha o corpo em linha reta da cabeça aos calcanhares.',
      'Contraia glúteos e abdômen intensamente.'
    ],
    postureAlerts: [
      'Não levante o bumbum muito alto.',
      'Não deixe a lombar arquear para baixo.'
    ],
    breathing: 'Mantenha uma respiração constante e profunda.',
    animationUrl: 'https://media.giphy.com/media/v1.Y2lkPTc5MGI3NjExNjk1OTQ4NDY5NDY5NDY5NDY5NDY5NDY5NDY5NDY5NDY5NDY5NDY5JmVwX3YxX2ludGVybmFsX2dpZl9ieV9pZCZjdD1n/m949Yw28FMTuof05hO/giphy.gif'
  },
  'dips': {
    id: 'dips',
    name: 'Paralelas',
    muscles: [MuscleGroup.TRICEPS, MuscleGroup.CHEST, MuscleGroup.SHOULDERS],
    description: 'O agachamento da parte superior do corpo.',
    instructions: [
      'Mantenha-se suspenso nas barras paralelas.',
      'Desça o corpo dobrando os braços até 90 graus.',
      'Empurre de volta com força total.'
    ],
    postureAlerts: [
      'Não desça demais para não sobrecarregar os ombros.',
      'Incline-se levemente para frente para focar no peito.'
    ],
    breathing: 'Expire no esforço de subida.',
    animationUrl: 'https://media.giphy.com/media/v1.Y2lkPTc5MGI3NjExNjk1OTQ4NDY5NDY5NDY5NDY5NDY5NDY5NDY5NDY5NDY5NDY5NDY5JmVwX3YxX2ludGVybmFsX2dpZl9ieV9pZCZjdD1n/L59v2V1oT8z39SclKq/giphy.gif'
  },
  'leg_raise': {
    id: 'leg_raise',
    name: 'Elevação de Pernas',
    muscles: [MuscleGroup.ABS, MuscleGroup.CORE],
    description: 'Foco intenso no abdômen inferior.',
    instructions: [
      'Deitado de costas ou pendurado na barra.',
      'Suba as pernas esticadas até 90 graus.',
      'Desça controladamente sem tocar o chão.'
    ],
    postureAlerts: [
      'Não balance o corpo se estiver pendurado.',
      'Mantenha a lombar pressionada contra o chão se estiver deitado.'
    ],
    breathing: 'Expire ao subir as pernas.',
    animationUrl: 'https://media.giphy.com/media/v1.Y2lkPTc5MGI3NjExNjk1OTQ4NDY5NDY5NDY5NDY5NDY5NDY5NDY5NDY5NDY5NDY5NDY5JmVwX3YxX2ludGVybmFsX2dpZl9ieV9pZCZjdD1n/uVpP7tclM6T7X7I2O8/giphy.gif'
  }
};

export const WEEKLY_ROUTINE: WorkoutDay[] = [
  { dayName: 'Segunda-feira', focus: 'Peito + Tríceps', exercises: ['pushup', 'dips', 'plank'] },
  { dayName: 'Terça-feira', focus: 'Costas + Bíceps', exercises: ['pullup', 'leg_raise'] },
  { dayName: 'Quarta-feira', focus: 'Pernas + Core', exercises: ['squat', 'plank', 'leg_raise'] },
  { dayName: 'Quinta-feira', focus: 'Ombros + Abdômen', exercises: ['pushup', 'plank', 'leg_raise'] },
  { dayName: 'Sexta-feira', focus: 'Corpo Inteiro', exercises: ['pushup', 'pullup', 'squat', 'dips'] },
  { dayName: 'Sábado', focus: 'Desafio Calistênico', exercises: ['pullup', 'pushup', 'dips', 'squat', 'plank', 'leg_raise'] },
  { dayName: 'Domingo', focus: 'Recuperação + Alongamento', exercises: ['plank'] }
];

export const MOTIVATIONAL_QUOTES = [
  "Sua única competição é quem você era ontem.",
  "Calistenia não é sobre o que você pode levantar, é sobre o que você pode controlar.",
  "A disciplina te leva onde a motivação não consegue chegar.",
  "Sinta o arder hoje, sinta o poder amanhã.",
  "Domine seu próprio peso, domine seu mundo."
];
