
import { GoogleGenAI } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });

export const getAITrainingTip = async (muscleGroup: string): Promise<string> => {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `Forneça uma dica curta, profissional e motivacional de calistenia focada em ${muscleGroup}. Máximo 15 palavras. Em Português Brasileiro.`,
      config: {
        temperature: 0.7,
      }
    });
    return response.text || "Mantenha o foco e a forma impecável!";
  } catch (error) {
    console.error("Gemini Error:", error);
    return "Sua força vem da sua consistência. Continue firme!";
  }
};
