
import React, { useState, useEffect } from 'react';
import { Difficulty, MuscleGroup, UserStats } from './types';
import { EXERCISES, WEEKLY_ROUTINE, MOTIVATIONAL_QUOTES } from './constants';
import WorkoutTimer from './components/WorkoutTimer';

const App: React.FC = () => {
  const [stats, setStats] = useState<UserStats>({
    streak: 3,
    completedWorkouts: 12,
    weeklyGoal: 5,
    currentDifficulty: Difficulty.INTERMEDIATE
  });

  const [activeWorkout, setActiveWorkout] = useState<string[] | null>(null);
  const [isWorkoutComplete, setIsWorkoutComplete] = useState(false);
  const [quote, setQuote] = useState(MOTIVATIONAL_QUOTES[0]);

  useEffect(() => {
    setQuote(MOTIVATIONAL_QUOTES[Math.floor(Math.random() * MOTIVATIONAL_QUOTES.length)]);
  }, []);

  const handleStartWorkout = (exerciseIds: string[]) => {
    setActiveWorkout(exerciseIds);
  };

  const handleCompleteWorkout = () => {
    setStats(prev => ({
      ...prev,
      completedWorkouts: prev.completedWorkouts + 1,
      streak: prev.streak + 1
    }));
    setActiveWorkout(null);
    setIsWorkoutComplete(true);
    setTimeout(() => setIsWorkoutComplete(false), 5000);
  };

  const todayIndex = new Date().getDay(); // 0=Sun, 1=Mon...
  // Map JS Day to our Routine (Mon starts at index 0)
  const adjustedToday = todayIndex === 0 ? 6 : todayIndex - 1;
  const todayWorkout = WEEKLY_ROUTINE[adjustedToday];

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col max-w-md mx-auto shadow-2xl overflow-x-hidden relative">
      {/* Header */}
      <header className="p-6 pt-12 flex justify-between items-end">
        <div>
          <h1 className="text-3xl font-black text-white tracking-tighter">CALI<span className="text-orange-500">PRO</span></h1>
          <p className="text-slate-400 text-sm font-medium">Nível: {stats.currentDifficulty}</p>
        </div>
        <div className="bg-slate-900 px-3 py-1.5 rounded-2xl flex items-center gap-2 border border-slate-800 shadow-lg">
          <i className="fa-solid fa-fire text-orange-500"></i>
          <span className="font-bold text-lg">{stats.streak}</span>
        </div>
      </header>

      {/* Main Scroll Content */}
      <main className="flex-1 px-6 space-y-8 pb-32 overflow-y-auto no-scrollbar">
        
        {/* Quote Card */}
        <div className="bg-gradient-to-br from-slate-900 to-slate-950 p-5 rounded-3xl border border-slate-800 relative overflow-hidden group">
          <div className="absolute top-0 right-0 w-32 h-32 bg-orange-500/10 rounded-full -mr-16 -mt-16 blur-3xl group-hover:bg-orange-500/20 transition-all duration-700"></div>
          <i className="fa-solid fa-quote-left text-slate-700 text-3xl mb-2"></i>
          <p className="text-lg font-semibold leading-tight italic text-slate-200">"{quote}"</p>
        </div>

        {/* Today's Workout Focus */}
        <section>
          <div className="flex justify-between items-center mb-4">
            <h2 className="text-xl font-bold">Treino de Hoje</h2>
            <span className="text-xs font-bold text-orange-500 uppercase tracking-widest">{todayWorkout.dayName}</span>
          </div>
          <div 
            onClick={() => handleStartWorkout(todayWorkout.exercises)}
            className="bg-slate-900 rounded-3xl p-6 border border-slate-800 hover:border-orange-500/50 transition-all cursor-pointer group relative overflow-hidden shadow-2xl"
          >
            <div className="flex justify-between items-center relative z-10">
              <div>
                <h3 className="text-2xl font-black mb-1">{todayWorkout.focus}</h3>
                <p className="text-slate-400 text-sm flex items-center gap-2">
                  <i className="fa-solid fa-clock"></i> ~15-20 min • {todayWorkout.exercises.length} exercícios
                </p>
              </div>
              <div className="w-12 h-12 rounded-full bg-orange-500 flex items-center justify-center text-white shadow-lg group-hover:scale-110 transition-transform">
                <i className="fa-solid fa-play ml-1"></i>
              </div>
            </div>
            
            {/* Visual muscle groups chips */}
            <div className="flex gap-2 mt-4 relative z-10">
              {todayWorkout.exercises.slice(0, 3).map(id => (
                <span key={id} className="text-[10px] bg-slate-800 px-2 py-1 rounded-lg text-slate-300 uppercase font-bold">
                   {EXERCISES[id].muscles[0]}
                </span>
              ))}
            </div>

            <img 
              src="https://picsum.photos/seed/cali/400/200" 
              alt="Training" 
              className="absolute inset-0 w-full h-full object-cover opacity-10 group-hover:opacity-20 transition-opacity"
            />
          </div>
        </section>

        {/* Routine Tracker */}
        <section>
          <h2 className="text-xl font-bold mb-4">Rotina Semanal</h2>
          <div className="flex gap-3 overflow-x-auto no-scrollbar pb-2">
            {WEEKLY_ROUTINE.map((day, i) => (
              <div 
                key={day.dayName} 
                className={`min-w-[100px] p-4 rounded-2xl flex flex-col items-center justify-center border transition-all ${i === adjustedToday ? 'bg-orange-500 border-orange-400 text-white shadow-lg shadow-orange-500/20 scale-105' : 'bg-slate-900 border-slate-800 text-slate-400'}`}
              >
                <span className="text-[10px] font-bold uppercase mb-1 opacity-80">{day.dayName.substring(0, 3)}</span>
                <i className={`fa-solid ${i === adjustedToday ? 'fa-dumbbell' : i < adjustedToday ? 'fa-circle-check text-green-500' : 'fa-circle-dot'} text-xl mb-1`}></i>
              </div>
            ))}
          </div>
        </section>

        {/* Muscle Anatomy Highlights */}
        <section>
          <div className="flex justify-between items-center mb-4">
            <h2 className="text-xl font-bold">Destaque Muscular</h2>
            <button className="text-xs text-blue-400 font-bold uppercase">Ver Todos</button>
          </div>
          <div className="bg-slate-900 rounded-3xl p-6 border border-slate-800 flex items-center gap-6">
            <div className="w-24 h-40 bg-slate-950 rounded-2xl p-2 border border-slate-800 shadow-inner">
              <img src="https://media.giphy.com/media/v1.Y2lkPTc5MGI3NjExM3FkbWp2OW0zaWpsN3R1ZThqY2Zna2p6YjR1YjR1YjR1YjR1YjR1YjR1JmVwX3YxX2ludGVybmFsX2dpZl9ieV9pZCZjdD1n/m949Yw28FMTuof05hO/giphy.gif" className="w-full h-full object-contain opacity-60 grayscale hover:grayscale-0 transition-all cursor-pointer" alt="Body" />
            </div>
            <div className="flex-1 space-y-3">
              <div>
                <p className="text-xs font-bold text-slate-500 uppercase tracking-tighter">Foco Principal</p>
                <p className="text-lg font-bold text-white">Peitoral & Dorsais</p>
              </div>
              <div className="flex flex-wrap gap-2">
                {[MuscleGroup.CHEST, MuscleGroup.BACK, MuscleGroup.CORE].map(m => (
                  <span key={m} className="px-2 py-0.5 bg-slate-800 rounded text-[10px] font-medium text-slate-400 border border-slate-700">{m}</span>
                ))}
              </div>
            </div>
          </div>
        </section>
      </main>

      {/* Tab Navigation */}
      <nav className="fixed bottom-0 left-0 right-0 bg-slate-900/80 backdrop-blur-xl border-t border-slate-800 p-4 max-w-md mx-auto z-40">
        <div className="flex justify-around items-center">
          <button className="flex flex-col items-center gap-1 text-orange-500">
            <i className="fa-solid fa-house-chimney text-xl"></i>
            <span className="text-[10px] font-bold">Início</span>
          </button>
          <button className="flex flex-col items-center gap-1 text-slate-500 hover:text-white transition-colors">
            <i className="fa-solid fa-chart-simple text-xl"></i>
            <span className="text-[10px] font-bold">Progresso</span>
          </button>
          <div className="w-14 h-14 bg-orange-500 rounded-full flex items-center justify-center text-white -mt-12 shadow-2xl border-4 border-slate-950 shadow-orange-500/40 cursor-pointer hover:scale-110 transition-transform active:scale-95">
            <i className="fa-solid fa-dumbbell text-2xl"></i>
          </div>
          <button className="flex flex-col items-center gap-1 text-slate-500 hover:text-white transition-colors">
            <i className="fa-solid fa-user-graduate text-xl"></i>
            <span className="text-[10px] font-bold">Aulas</span>
          </button>
          <button className="flex flex-col items-center gap-1 text-slate-500 hover:text-white transition-colors">
            <i className="fa-solid fa-gear text-xl"></i>
            <span className="text-[10px] font-bold">Ajustes</span>
          </button>
        </div>
      </nav>

      {/* Workout Session Overlay */}
      {activeWorkout && (
        <WorkoutTimer 
          exercises={activeWorkout.map(id => EXERCISES[id])}
          difficulty={stats.currentDifficulty}
          onExit={() => setActiveWorkout(null)}
          onComplete={handleCompleteWorkout}
        />
      )}

      {/* Success Modal */}
      {isWorkoutComplete && (
        <div className="fixed inset-0 bg-slate-950/90 z-[60] flex items-center justify-center p-6 animate-in zoom-in duration-300">
          <div className="bg-slate-900 border border-orange-500/30 rounded-3xl p-8 text-center shadow-2xl">
            <div className="w-20 h-20 bg-green-500 rounded-full flex items-center justify-center text-white text-4xl mx-auto mb-6 shadow-lg shadow-green-500/20">
              <i className="fa-solid fa-check"></i>
            </div>
            <h2 className="text-3xl font-black mb-2">TREINO CONCLUÍDO!</h2>
            <p className="text-slate-400 mb-6 italic">"A maestria vem da repetição implacável."</p>
            <div className="grid grid-cols-2 gap-4">
              <div className="bg-slate-800 p-4 rounded-2xl">
                <p className="text-xs text-slate-500 font-bold uppercase mb-1">Duração</p>
                <p className="text-xl font-black text-white">~15 min</p>
              </div>
              <div className="bg-slate-800 p-4 rounded-2xl">
                <p className="text-xs text-slate-500 font-bold uppercase mb-1">Pontos</p>
                <p className="text-xl font-black text-orange-500">+150 XP</p>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default App;
