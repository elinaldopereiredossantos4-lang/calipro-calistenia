
export enum Difficulty {
  BEGINNER = 'Iniciante',
  INTERMEDIATE = 'Intermediário',
  ADVANCED = 'Avançado'
}

export enum MuscleGroup {
  CHEST = 'Peitoral',
  TRICEPS = 'Tríceps',
  BACK = 'Dorsais',
  BICEPS = 'Bíceps',
  LEGS = 'Pernas',
  CORE = 'Core',
  SHOULDERS = 'Ombros',
  ABS = 'Abdômen',
  FULL_BODY = 'Corpo Inteiro'
}

export interface Exercise {
  id: string;
  name: string;
  muscles: MuscleGroup[];
  description: string;
  instructions: string[];
  postureAlerts: string[];
  breathing: string;
  animationUrl: string;
  duration?: number; // seconds
  reps?: number;
}

export interface WorkoutDay {
  dayName: string;
  focus: string;
  exercises: string[]; // List of exercise IDs
}

export interface UserStats {
  streak: number;
  completedWorkouts: number;
  weeklyGoal: number;
  currentDifficulty: Difficulty;
}
