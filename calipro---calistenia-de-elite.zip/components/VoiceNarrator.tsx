
import React, { useEffect, useCallback } from 'react';

interface VoiceNarratorProps {
  text: string;
  trigger: any;
}

const VoiceNarrator: React.FC<VoiceNarratorProps> = ({ text, trigger }) => {
  const speak = useCallback((msg: string) => {
    if (!window.speechSynthesis) return;

    // Cancel existing speech
    window.speechSynthesis.cancel();

    const utterance = new SpeechSynthesisUtterance(msg);
    utterance.lang = 'pt-BR';
    
    // Attempt to find a male voice
    const voices = window.speechSynthesis.getVoices();
    const maleVoice = voices.find(v => 
      v.lang.startsWith('pt') && 
      (v.name.toLowerCase().includes('male') || v.name.toLowerCase().includes('homem') || v.name.toLowerCase().includes('premium'))
    );
    
    if (maleVoice) {
      utterance.voice = maleVoice;
    }
    
    utterance.pitch = 0.9; // Lower pitch for firmer voice
    utterance.rate = 1.0;
    
    window.speechSynthesis.speak(utterance);
  }, []);

  useEffect(() => {
    if (text) {
      speak(text);
    }
  }, [text, trigger, speak]);

  return null;
};

export default VoiceNarrator;
