
import React, { useState, useEffect, useCallback } from 'react';
import { Exercise, Difficulty, MuscleGroup } from '../types';
import BodyMap from './BodyMap';
import VoiceNarrator from './VoiceNarrator';
import { getAITrainingTip } from '../services/geminiService';

interface WorkoutTimerProps {
  exercises: Exercise[];
  difficulty: Difficulty;
  onComplete: () => void;
  onExit: () => void;
}

const WorkoutTimer: React.FC<WorkoutTimerProps> = ({ exercises, difficulty, onComplete, onExit }) => {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [timeLeft, setTimeLeft] = useState(30); // Default per exercise
  const [isResting, setIsResting] = useState(false);
  const [isPaused, setIsPaused] = useState(false);
  const [narrationText, setNarrationText] = useState('');
  const [aiTip, setAiTip] = useState('');

  const currentExercise = exercises[currentIndex];

  const getMultiplier = () => {
    if (difficulty === Difficulty.BEGINNER) return 1;
    if (difficulty === Difficulty.INTERMEDIATE) return 1.5;
    return 2;
  };

  const startExercise = useCallback(() => {
    const baseTime = 30;
    setTimeLeft(Math.floor(baseTime * getMultiplier()));
    setIsResting(false);
    setNarrationText(`Comece agora: ${currentExercise.name}. ${currentExercise.instructions[0]}`);
    
    // Fetch AI tip dynamically
    getAITrainingTip(currentExercise.muscles[0]).then(setAiTip);
  }, [currentExercise, difficulty]);

  const startRest = useCallback(() => {
    setTimeLeft(15);
    setIsResting(true);
    setNarrationText("Hora de descansar. Respire fundo e prepare-se para o próximo.");
  }, []);

  useEffect(() => {
    startExercise();
  }, [currentIndex]); // eslint-disable-line react-hooks/exhaustive-deps

  useEffect(() => {
    if (isPaused) return;

    if (timeLeft <= 0) {
      if (!isResting) {
        if (currentIndex < exercises.length - 1) {
          startRest();
        } else {
          onComplete();
        }
      } else {
        setCurrentIndex(prev => prev + 1);
      }
      return;
    }

    const timer = setInterval(() => {
      setTimeLeft(prev => prev - 1);
      
      // Countdown audio cues
      if (timeLeft === 10) setNarrationText("Restam 10 segundos. Mantenha a forma!");
      if (timeLeft <= 3 && timeLeft > 0) setNarrationText(timeLeft.toString());
    }, 1000);

    return () => clearInterval(timer);
  }, [timeLeft, isResting, isPaused, currentIndex, exercises.length, onComplete, startRest]);

  return (
    <div className="fixed inset-0 bg-slate-950 z-50 flex flex-col p-6 animate-in fade-in slide-in-from-bottom duration-500">
      <VoiceNarrator text={narrationText} trigger={narrationText} />
      
      {/* Header */}
      <div className="flex justify-between items-center mb-6">
        <button onClick={onExit} className="text-slate-400 hover:text-white transition-colors">
          <i className="fa-solid fa-xmark text-2xl"></i>
        </button>
        <div className="text-center">
          <p className="text-xs uppercase tracking-widest text-slate-500">Exercício {currentIndex + 1} de {exercises.length}</p>
          <h2 className="text-xl font-bold">{isResting ? "DESCANSO" : currentExercise.name}</h2>
        </div>
        <div className="w-8" />
      </div>

      {/* Main Visualizer */}
      <div className="flex-1 flex flex-col lg:flex-row gap-6 overflow-hidden">
        {/* Animation & Anatomy */}
        <div className="flex-1 bg-slate-900 rounded-3xl p-4 flex flex-col items-center justify-center relative overflow-hidden">
          {!isResting ? (
            <>
              <img 
                src={currentExercise.animationUrl} 
                alt={currentExercise.name}
                className="max-h-64 object-contain rounded-xl mb-4"
              />
              <div className="absolute top-4 right-4 w-24 h-48 bg-slate-800/50 rounded-2xl backdrop-blur-sm p-2">
                <BodyMap activeMuscles={currentExercise.muscles} className="h-full" />
              </div>
            </>
          ) : (
            <div className="flex flex-col items-center justify-center space-y-4 text-orange-500">
              <i className="fa-solid fa-mug-hot text-6xl animate-bounce"></i>
              <p className="text-xl font-medium">Prepare-se: {exercises[currentIndex + 1]?.name}</p>
            </div>
          )}
        </div>

        {/* Controls & Instructions */}
        <div className="lg:w-96 flex flex-col gap-4">
          {/* Timer Card */}
          <div className="bg-slate-900 rounded-3xl p-8 flex flex-col items-center justify-center shadow-xl border border-slate-800">
            <div className="relative w-40 h-40 flex items-center justify-center">
              <svg className="absolute inset-0 w-full h-full -rotate-90">
                <circle 
                  cx="80" cy="80" r="70" 
                  fill="none" stroke="#1e293b" strokeWidth="8" 
                />
                <circle 
                  cx="80" cy="80" r="70" 
                  fill="none" stroke={isResting ? "#10b981" : "#f97316"} 
                  strokeWidth="8" 
                  strokeDasharray={440}
                  strokeDashoffset={440 - (440 * timeLeft) / (isResting ? 15 : 30 * getMultiplier())}
                  className="transition-all duration-1000 ease-linear"
                />
              </svg>
              <span className="text-5xl font-black tabular-nums">{timeLeft}</span>
            </div>

            <div className="flex gap-4 mt-8">
              <button 
                onClick={() => setIsPaused(!isPaused)}
                className={`w-14 h-14 rounded-full flex items-center justify-center transition-all ${isPaused ? 'bg-orange-500 text-white' : 'bg-slate-800 text-slate-300'}`}
              >
                <i className={`fa-solid ${isPaused ? 'fa-play' : 'fa-pause'} text-xl`}></i>
              </button>
              <button 
                onClick={() => setTimeLeft(0)}
                className="w-14 h-14 rounded-full bg-slate-800 text-slate-300 flex items-center justify-center"
              >
                <i className="fa-solid fa-forward text-xl"></i>
              </button>
            </div>
          </div>

          {/* AI Tip / Instruction Card */}
          <div className="bg-blue-600/10 border border-blue-500/20 rounded-2xl p-4">
            <div className="flex items-center gap-2 mb-2 text-blue-400">
              <i className="fa-solid fa-robot"></i>
              <span className="text-xs font-bold uppercase">Dica do CaliPro AI</span>
            </div>
            <p className="text-sm italic text-blue-100">"{aiTip || 'Processando técnica...'}"</p>
          </div>

          {!isResting && (
            <div className="bg-slate-900 rounded-2xl p-4 flex-1 overflow-y-auto no-scrollbar">
              <h3 className="font-bold text-sm mb-3 text-slate-400 uppercase tracking-widest">Execução Correta</h3>
              <ul className="space-y-3">
                {currentExercise.instructions.map((inst, i) => (
                  <li key={i} className="flex gap-3 text-sm">
                    <span className="w-5 h-5 rounded-full bg-slate-800 flex-shrink-0 flex items-center justify-center text-[10px] font-bold">{i+1}</span>
                    <span className="text-slate-200">{inst}</span>
                  </li>
                ))}
              </ul>
              <div className="mt-4 pt-4 border-t border-slate-800">
                <p className="text-xs font-bold text-orange-400 mb-1">Atenção à Postura:</p>
                {currentExercise.postureAlerts.map((alert, i) => (
                   <p key={i} className="text-xs text-slate-400 flex items-start gap-2">
                     <i className="fa-solid fa-triangle-exclamation text-orange-500 mt-0.5"></i>
                     {alert}
                   </p>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default WorkoutTimer;
