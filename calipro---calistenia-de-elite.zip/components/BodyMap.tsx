
import React from 'react';
import { MuscleGroup } from '../types';

interface BodyMapProps {
  activeMuscles: MuscleGroup[];
  className?: string;
}

const BodyMap: React.FC<BodyMapProps> = ({ activeMuscles, className }) => {
  const isHighlighted = (groups: MuscleGroup[]) => 
    groups.some(g => activeMuscles.includes(g));

  const getColor = (groups: MuscleGroup[]) => 
    isHighlighted(groups) ? '#f97316' : '#334155'; // Orange vs Slate-700

  return (
    <div className={`relative ${className}`}>
      <svg viewBox="0 0 200 400" className="w-full h-full">
        {/* Head */}
        <circle cx="100" cy="40" r="20" fill="#1e293b" />
        
        {/* Torso/Chest */}
        <path 
          d="M70 70 L130 70 L135 150 L65 150 Z" 
          fill={getColor([MuscleGroup.CHEST, MuscleGroup.CORE, MuscleGroup.BACK])} 
          className="muscle-highlight"
        />
        
        {/* Abs */}
        <path 
          d="M75 155 L125 155 L120 200 L80 200 Z" 
          fill={getColor([MuscleGroup.ABS, MuscleGroup.CORE])} 
          className="muscle-highlight"
        />

        {/* Arms - Upper Left */}
        <rect 
          x="45" y="75" width="20" height="60" rx="5" 
          fill={getColor([MuscleGroup.BICEPS, MuscleGroup.TRICEPS, MuscleGroup.SHOULDERS])} 
          className="muscle-highlight"
        />
        {/* Arms - Upper Right */}
        <rect 
          x="135" y="75" width="20" height="60" rx="5" 
          fill={getColor([MuscleGroup.BICEPS, MuscleGroup.TRICEPS, MuscleGroup.SHOULDERS])} 
          className="muscle-highlight"
        />

        {/* Legs - Upper Left */}
        <path 
          d="M75 205 L95 205 L95 300 L70 300 Z" 
          fill={getColor([MuscleGroup.LEGS])} 
          className="muscle-highlight"
        />
        {/* Legs - Upper Right */}
        <path 
          d="M105 205 L125 205 L130 300 L105 300 Z" 
          fill={getColor([MuscleGroup.LEGS])} 
          className="muscle-highlight"
        />
        
        {/* Labels for UX */}
        <text x="50%" y="380" textAnchor="middle" fill="#94a3b8" fontSize="12" fontWeight="bold">
          {activeMuscles.join(' • ')}
        </text>
      </svg>
    </div>
  );
};

export default BodyMap;
